// Sariq Coin local frontend server; not intended for production hosting.
// Serves frontend/public and forwards API and protected video traffic to backend.
// The proxy maintains one browser origin so HttpOnly SameSite cookies work.
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
const publicRoot=path.join(root,'public');
const host=process.env.FRONTEND_HOST||'127.0.0.1';
const port=Number(process.env.FRONTEND_PORT||5173);
const upstream=new URL(process.env.BACKEND_URL||'http://127.0.0.1:8080');
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.ico':'image/x-icon'};
const allowed=new Set(['/index.html','/admin.html','/style.css','/app.js','/video.js','/admin.js','/favicon.svg']);
function proxy(req,res){
  const headers={...req.headers,host:req.headers.host};
  delete headers.connection; delete headers['proxy-connection'];
  const target=http.request({hostname:upstream.hostname,port:upstream.port||80,method:req.method,path:req.url,headers,timeout:30000},response=>{
    res.writeHead(response.statusCode||502,response.headers);response.pipe(res);
  });
  target.on('timeout',()=>target.destroy(new Error('Backend timeout')));
  target.on('error',e=>{console.error('[Frontend proxy]',e.message);if(!res.headersSent){res.writeHead(502,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify({error:'Backend ishlamayapti. backend/ papkasida node server.mjs buyrug‘ini ishga tushiring.'}));}else res.destroy();});
  req.pipe(target);
}
const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','no-referrer');
  try{
    const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`);
    const route=url.pathname;
    if(route.startsWith('/api/')||route.startsWith('/media/videos/')||route==='/healthz')return proxy(req,res);
    if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end();}
    let p=route;
    if(p==='/')p='/index.html';
    if(p==='/admin')p='/admin.html';
    if(!allowed.has(p)&&!/^\/assets\/[a-z0-9-]+\.(png|webp)$/.test(p)){res.writeHead(404);return res.end('Not found');}
    const file=path.join(publicRoot,p);
    const contents=await fs.readFile(file);
    res.writeHead(200,{'Content-Type':mime[path.extname(p)]||'application/octet-stream','Cache-Control':'no-cache','Content-Security-Policy':"default-src 'self'; script-src 'self' https://telegram.org; style-src 'self'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'self' https://web.telegram.org https://*.telegram.org; base-uri 'self'; object-src 'none'"});
    res.end(req.method==='HEAD'?undefined:contents);
  }catch(e){res.writeHead(e.code==='ENOENT'?404:500);res.end('Not found');}
});
server.on('error',err=>{console.error('[Frontend]',err.message);process.exitCode=1;});
server.listen(port,host,()=>console.log(`Frontend: http://${host}:${port}/ | backend: ${upstream.origin}`));
